package book.jeepatterns.model;

import book.jeepatterns.qualifier.Mechanical;

@Mechanical
public class MechanicalEngineering extends BasicEngineering {

}
