package book.jeepatterns.model;

import java.util.List;

public interface Engineering {
	//List<Discipline> getDisciplines();
	List<String> getDisciplines ();
}
