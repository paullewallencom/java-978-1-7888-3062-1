package book.jeepatterns.facade;

public interface FinancialFacade {

}
