package book.jeepatterns.microservice.resource;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath ("ws")
public class JAXRSConfiguration extends Application {

}
