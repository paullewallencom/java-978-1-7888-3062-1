package com.packt.javaee8.business;

public interface Business <T> {

}
