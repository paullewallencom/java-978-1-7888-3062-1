package com.packt.javaee8.entity;

public interface Entity < T > {

    public T getId();
}
