package book.jeepatterns.model;

import book.jeepatterns.qualifier.Electronic;

@Electronic
public class ElectronicEngineering extends BasicEngineering {
}
