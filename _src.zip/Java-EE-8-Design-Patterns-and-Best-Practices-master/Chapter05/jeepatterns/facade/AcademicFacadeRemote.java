package book.jeepatterns.facade;

import javax.ejb.Remote;

@Remote
public interface AcademicFacadeRemote extends AcademicFacade {

}
